# Claude Obsidian Skills — Install Guide

**Source:** [github.com/AgriciDaniel/claude-obsidian](https://github.com/AgriciDaniel/claude-obsidian)
**Foundation:** [github.com/kepano/obsidian-skills](https://github.com/kepano/obsidian-skills)
**Pattern:** Andrej Karpathy's LLM wiki — compile knowledge once into interconnected markdown files instead of re-asking Claude the same questions repeatedly.

## Skills included (11)

| Skill | Purpose |
|-------|---------|
| `wiki` | Core orchestrator — scaffolds vault, routes to sub-skills |
| `wiki-ingest` | Read a source, extract entities/concepts, create/update wiki pages |
| `wiki-query` | Answer questions from the vault; files good answers back |
| `wiki-lint` | Health check — orphan pages, dead links, frontmatter gaps |
| `wiki-fold` | Roll up log entries into extractive meta-pages (DragonScale) |
| `save` | Save a conversation or insight as a structured wiki note |
| `canvas` | Visual layer — Obsidian canvas files with auto-positioning |
| `autoresearch` | Autonomous research loop; files findings directly into the wiki |
| `obsidian-markdown` | Reference for Obsidian Flavored Markdown syntax |
| `obsidian-bases` | Create/edit Obsidian Bases (.base files) for dynamic views |
| `defuddle` | Strip clutter from web pages before ingesting (saves 40-60% tokens) |

## Install (all 11 skills at once)

```bash
cd ~/.claude/skills
unzip /path/to/claude-obsidian-skills.zip -d .
```

Or from source:

```bash
cp -r skills/* ~/.claude/skills/
```

## Install via upstream marketplace

```bash
claude plugin marketplace add AgriciDaniel/claude-obsidian
```

## Recommended first steps after install

1. Open a new Claude Code session in your project folder
2. Type: `set up wiki` — Claude will scaffold the vault structure
3. Type: `ingest` + drop a file into `.raw/` — Claude ingests it into the wiki
4. Type: `what do you know about [topic]` — Claude queries the wiki

## Optional: DragonScale Memory extension

DragonScale adds 4 memory mechanisms: log folds, deterministic page addresses, semantic tiling lint, and boundary-first autoresearch. Install from upstream:

```bash
bash bin/setup-dragonscale.sh
```
